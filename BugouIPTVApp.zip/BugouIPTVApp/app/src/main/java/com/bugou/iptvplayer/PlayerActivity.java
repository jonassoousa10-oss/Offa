package com.bugou.iptvplayer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;

import java.security.MessageDigest;

public class PlayerActivity extends Activity {
    private ExoPlayer player;
    private PlayerView playerView;
    private SharedPreferences prefs;
    private String url;
    private String name;
    private boolean prepared = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        hideSystemUi();
        prefs = getSharedPreferences("bugou_iptv", MODE_PRIVATE);
        name = getIntent().getStringExtra("name");
        url = getIntent().getStringExtra("url");
        if (name == null) name = "Reprodução";
        if (url == null || url.trim().isEmpty()) {
            Toast.makeText(this, "Link vazio", Toast.LENGTH_LONG).show();
            finish();
            return;
        }
        buildUi();
        createPlayer();
        long last = prefs.getLong(positionKey(), 0L);
        if (last > 15000L) askResume(last); else prepareAndPlay(0L);
    }

    private void buildUi() {
        FrameLayout root = new FrameLayout(this);
        root.setBackgroundColor(Color.BLACK);
        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setControllerAutoShow(true);
        playerView.setControllerShowTimeoutMs(4500);
        playerView.setKeepScreenOn(true);
        root.addView(playerView, new FrameLayout.LayoutParams(-1, -1));

        TextView title = new TextView(this);
        title.setText(name);
        title.setTextColor(Color.WHITE);
        title.setTextSize(18);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setSingleLine(true);
        title.setShadowLayer(5, 1, 1, Color.BLACK);
        title.setPadding(dp(14), dp(10), dp(14), dp(10));
        FrameLayout.LayoutParams tp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP | Gravity.LEFT);
        root.addView(title, tp);
        setContentView(root);
    }

    private void createPlayer() {
        player = new ExoPlayer.Builder(this).build();
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_ENDED) {
                    prefs.edit().remove(positionKey()).apply();
                    Toast.makeText(PlayerActivity.this, "Conteúdo finalizado", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onPlayerError(PlaybackException error) {
                showPlayerError(error == null ? "Erro desconhecido" : error.getMessage());
            }
        });
    }

    private void askResume(final long last) {
        new AlertDialog.Builder(this)
                .setTitle("Continuar de onde parou?")
                .setMessage("Esse conteúdo tem progresso salvo. Deseja continuar ou reiniciar?")
                .setPositiveButton("Continuar", (d, w) -> prepareAndPlay(last))
                .setNegativeButton("Reiniciar", (d, w) -> prepareAndPlay(0L))
                .setOnCancelListener(d -> prepareAndPlay(last))
                .show();
    }

    private void prepareAndPlay(long position) {
        if (prepared) return;
        prepared = true;
        MediaItem item = MediaItem.fromUri(Uri.parse(url));
        player.setMediaItem(item);
        player.prepare();
        if (position > 0) player.seekTo(position);
        player.play();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && player != null) {
            int code = event.getKeyCode();
            if (code == KeyEvent.KEYCODE_DPAD_LEFT || code == KeyEvent.KEYCODE_MEDIA_REWIND) {
                seekBy(-10000);
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT || code == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) {
                seekBy(10000);
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) {
                if (player.isPlaying()) player.pause(); else player.play();
                playerView.showController();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    private void seekBy(long delta) {
        long current = player.getCurrentPosition();
        long duration = player.getDuration();
        long next = current + delta;
        if (next < 0) next = 0;
        if (duration > 0 && next > duration) next = duration;
        player.seekTo(next);
        playerView.showController();
    }

    private void showPlayerError(String msg) {
        new AlertDialog.Builder(this)
                .setTitle("Não foi possível reproduzir")
                .setMessage("Verifique se o link está online e se sua internet está funcionando.\n\nDetalhe: " + msg)
                .setPositiveButton("Fechar", (d, w) -> finish())
                .show();
    }

    private void saveProgress() {
        if (player == null || url == null) return;
        long pos = player.getCurrentPosition();
        long dur = player.getDuration();
        if (pos > 10000L && (dur <= 0 || pos < dur - 10000L)) prefs.edit().putLong(positionKey(), pos).apply();
    }

    @Override
    protected void onPause() {
        saveProgress();
        if (player != null) player.pause();
        super.onPause();
    }

    @Override
    protected void onStop() {
        saveProgress();
        super.onStop();
    }

    @Override
    protected void onDestroy() {
        saveProgress();
        if (player != null) {
            player.release();
            player = null;
        }
        super.onDestroy();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemUi();
    }

    private void hideSystemUi() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    private String positionKey() {
        return "pos_" + sha1(url == null ? "" : url);
    }

    private String sha1(String input) {
        try {
            MessageDigest md = MessageDigest.getInstance("SHA-1");
            byte[] b = md.digest(input.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format("%02x", x));
            return sb.toString();
        } catch (Exception e) {
            return String.valueOf(input.hashCode());
        }
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }
}
