package com.bugou.iptvplayer;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.InputStream;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int REQ_FILE = 7001;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private SharedPreferences prefs;
    private final ArrayList<IptvItem> allItems = new ArrayList<>();
    private final ArrayList<IptvItem> filteredItems = new ArrayList<>();
    private GridView grid;
    private CardAdapter adapter;
    private TextView status;
    private LinearLayout categoryBar;
    private EditText search;
    private ProgressBar progress;
    private String currentType = "Todos";
    private String currentGroup = "Todos";
    private boolean favoritesOnly = false;
    private HashSet<String> favoriteUrls = new HashSet<>();

    private final int bg = Color.rgb(8, 11, 16);
    private final int card = Color.rgb(17, 24, 34);
    private final int card2 = Color.rgb(24, 34, 49);
    private final int neon = Color.rgb(0, 245, 138);
    private final int blue = Color.rgb(61, 183, 255);
    private final int white = Color.WHITE;
    private final int soft = Color.rgb(190, 205, 218);

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        prefs = getSharedPreferences("bugou_iptv", MODE_PRIVATE);
        favoriteUrls = new HashSet<>(prefs.getStringSet("favorites", new HashSet<String>()));
        buildUi();
        restoreLastList();
    }

    @Override
    protected void onDestroy() {
        executor.shutdownNow();
        super.onDestroy();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(bg);
        root.setPadding(dp(10), dp(8), dp(10), dp(8));
        setContentView(root);

        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        root.addView(header, new LinearLayout.LayoutParams(-1, -2));

        TextView title = new TextView(this);
        title.setText("BUGOU IPTV");
        title.setTextColor(neon);
        title.setTextSize(isTv() ? 26 : 22);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setSingleLine(true);
        header.addView(title, new LinearLayout.LayoutParams(0, -2, 1));

        status = new TextView(this);
        status.setTextColor(soft);
        status.setTextSize(isTv() ? 15 : 12);
        status.setGravity(Gravity.RIGHT);
        status.setSingleLine(false);
        header.addView(status, new LinearLayout.LayoutParams(0, -2, 1));

        HorizontalScrollView topScroll = new HorizontalScrollView(this);
        topScroll.setHorizontalScrollBarEnabled(false);
        LinearLayout top = new LinearLayout(this);
        top.setOrientation(LinearLayout.HORIZONTAL);
        topScroll.addView(top);
        root.addView(topScroll, new LinearLayout.LayoutParams(-1, -2));

        addTopButton(top, "M3U URL", new View.OnClickListener() { public void onClick(View v) { showM3uDialog(); } });
        addTopButton(top, "Xtream", new View.OnClickListener() { public void onClick(View v) { showXtreamDialog(); } });
        addTopButton(top, "Arquivo", new View.OnClickListener() { public void onClick(View v) { openFile(); } });
        addTopButton(top, "Atualizar", new View.OnClickListener() { public void onClick(View v) { refreshLast(); } });
        addTopButton(top, "Todos", new View.OnClickListener() { public void onClick(View v) { selectType("Todos", false); } });
        addTopButton(top, "Canais", new View.OnClickListener() { public void onClick(View v) { selectType("Canal", false); } });
        addTopButton(top, "Filmes", new View.OnClickListener() { public void onClick(View v) { selectType("Filme", false); } });
        addTopButton(top, "Séries", new View.OnClickListener() { public void onClick(View v) { selectType("Série", false); } });
        addTopButton(top, "Favoritos", new View.OnClickListener() { public void onClick(View v) { selectType("Todos", true); } });
        addTopButton(top, "Limpar", new View.OnClickListener() { public void onClick(View v) { clearList(); } });
        addTopButton(top, "Ajuda", new View.OnClickListener() { public void onClick(View v) { showHelp(); } });

        search = new EditText(this);
        search.setSingleLine(true);
        search.setHint("Pesquisar canal, filme, série ou categoria...");
        search.setHintTextColor(Color.rgb(120, 135, 150));
        search.setTextColor(white);
        search.setTextSize(isTv() ? 18 : 15);
        search.setPadding(dp(14), dp(10), dp(14), dp(10));
        search.setBackground(round(card2, dp(14), Color.rgb(52, 71, 91), dp(1)));
        root.addView(search, new LinearLayout.LayoutParams(-1, -2));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            public void onTextChanged(CharSequence s, int st, int b, int c) { applyFilter(); }
            public void afterTextChanged(Editable s) {}
        });

        HorizontalScrollView catScroll = new HorizontalScrollView(this);
        catScroll.setHorizontalScrollBarEnabled(false);
        categoryBar = new LinearLayout(this);
        categoryBar.setOrientation(LinearLayout.HORIZONTAL);
        catScroll.addView(categoryBar);
        root.addView(catScroll, new LinearLayout.LayoutParams(-1, -2));

        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        root.addView(progress, new LinearLayout.LayoutParams(-1, dp(4)));

        grid = new GridView(this);
        grid.setBackgroundColor(bg);
        grid.setNumColumns(isTv() ? 5 : 2);
        grid.setHorizontalSpacing(dp(10));
        grid.setVerticalSpacing(dp(10));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setSelector(selectorGrid());
        grid.setDrawSelectorOnTop(true);
        grid.setClipToPadding(false);
        grid.setPadding(0, dp(8), 0, dp(12));
        adapter = new CardAdapter();
        grid.setAdapter(adapter);
        root.addView(grid, new LinearLayout.LayoutParams(-1, 0, 1));
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < filteredItems.size()) showItemActions(filteredItems.get(position));
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                if (position >= 0 && position < filteredItems.size()) toggleFavorite(filteredItems.get(position));
                return true;
            }
        });

        updateStatus("Cole sua lista M3U, carregue Xtream ou abra um arquivo .m3u");
        rebuildCategories();
    }

    private void restoreLastList() {
        String mode = prefs.getString("last_mode", "");
        if (mode.equals("m3u") || mode.equals("xtream")) {
            String url = prefs.getString("last_url", "");
            if (!url.isEmpty()) loadUrl(url, false, "Carregando lista salva...");
        }
    }

    private void refreshLast() {
        String url = prefs.getString("last_url", "");
        if (url.isEmpty()) {
            toast("Nenhuma lista salva ainda");
            return;
        }
        loadUrl(url, false, "Atualizando lista...");
    }

    private void showM3uDialog() {
        final EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setMinLines(2);
        input.setTextColor(Color.BLACK);
        input.setHint("https://seuservidor.com/lista.m3u");
        input.setText(prefs.getString("m3u_url", ""));
        input.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this)
                .setTitle("Adicionar lista M3U")
                .setMessage("Cole sua lista IPTV legal/autorizada. O app salva e carrega automaticamente depois.")
                .setView(input)
                .setPositiveButton("Carregar", (dialog, which) -> {
                    String url = input.getText().toString().trim();
                    if (!url.startsWith("http://") && !url.startsWith("https://")) { toast("URL inválida"); return; }
                    prefs.edit().putString("m3u_url", url).putString("last_url", url).putString("last_mode", "m3u").apply();
                    hideKeyboard(input);
                    loadUrl(url, true, "Carregando M3U...");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showXtreamDialog() {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(12);
        box.setPadding(pad, 0, pad, 0);
        final EditText server = dialogInput("Servidor: http://dns.com:8080", prefs.getString("xt_server", ""));
        final EditText user = dialogInput("Usuário", prefs.getString("xt_user", ""));
        final EditText pass = dialogInput("Senha", prefs.getString("xt_pass", ""));
        box.addView(server); box.addView(user); box.addView(pass);
        new AlertDialog.Builder(this)
                .setTitle("Login Xtream Codes")
                .setMessage("Digite os dados do seu painel/autorização. O app converte para M3U automaticamente.")
                .setView(box)
                .setPositiveButton("Carregar", (dialog, which) -> {
                    String s = server.getText().toString().trim();
                    String u = user.getText().toString().trim();
                    String p = pass.getText().toString().trim();
                    if (s.isEmpty() || u.isEmpty() || p.isEmpty()) { toast("Preencha servidor, usuário e senha"); return; }
                    if (!s.startsWith("http://") && !s.startsWith("https://")) s = "http://" + s;
                    if (s.endsWith("/")) s = s.substring(0, s.length() - 1);
                    try {
                        String url = s + "/get.php?username=" + URLEncoder.encode(u, "UTF-8") + "&password=" + URLEncoder.encode(p, "UTF-8") + "&type=m3u_plus&output=ts";
                        prefs.edit().putString("xt_server", s).putString("xt_user", u).putString("xt_pass", p).putString("last_url", url).putString("last_mode", "xtream").apply();
                        loadUrl(url, true, "Conectando Xtream...");
                    } catch (Exception e) { toast("Erro ao montar URL Xtream"); }
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private EditText dialogInput(String hint, String value) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setHint(hint);
        e.setText(value);
        e.setTextColor(Color.BLACK);
        e.setSelectAllOnFocus(true);
        e.setPadding(0, dp(8), 0, dp(8));
        return e;
    }

    private void openFile() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        startActivityForResult(i, REQ_FILE);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQ_FILE && resultCode == RESULT_OK && data != null && data.getData() != null) {
            Uri uri = data.getData();
            try { getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION); } catch (Exception ignored) {}
            loadFile(uri);
        }
    }

    private void loadUrl(final String url, final boolean userStarted, final String msg) {
        setLoading(true, msg);
        executor.execute(new Runnable() {
            public void run() {
                try {
                    final ArrayList<IptvItem> items = IptvParser.loadFromUrl(url);
                    main.post(new Runnable() { public void run() { setItems(items, "Lista carregada com sucesso"); } });
                } catch (final Exception e) {
                    main.post(new Runnable() { public void run() { setLoading(false, "Erro ao carregar"); showError("Não consegui carregar a lista", e.getMessage()); } });
                }
            }
        });
    }

    private void loadFile(final Uri uri) {
        setLoading(true, "Lendo arquivo...");
        executor.execute(new Runnable() {
            public void run() {
                try {
                    InputStream in = getContentResolver().openInputStream(uri);
                    final ArrayList<IptvItem> items = IptvParser.loadFromInputStream(in);
                    main.post(new Runnable() { public void run() { setItems(items, "Arquivo carregado"); } });
                } catch (final Exception e) {
                    main.post(new Runnable() { public void run() { setLoading(false, "Erro ao ler arquivo"); showError("Arquivo inválido", e.getMessage()); } });
                }
            }
        });
    }

    private void setItems(ArrayList<IptvItem> items, String message) {
        allItems.clear();
        allItems.addAll(items);
        Collections.sort(allItems, new Comparator<IptvItem>() { public int compare(IptvItem a, IptvItem b) { return a.name.compareToIgnoreCase(b.name); } });
        currentGroup = "Todos";
        favoritesOnly = false;
        setLoading(false, message);
        rebuildCategories();
        applyFilter();
        if (!filteredItems.isEmpty()) grid.requestFocus();
    }

    private void selectType(String type, boolean fav) {
        currentType = type;
        favoritesOnly = fav;
        currentGroup = "Todos";
        rebuildCategories();
        applyFilter();
    }

    private void applyFilter() {
        filteredItems.clear();
        String q = search == null ? "" : search.getText().toString().trim().toLowerCase(Locale.ROOT);
        for (IptvItem item : allItems) {
            if (favoritesOnly && !favoriteUrls.contains(item.url)) continue;
            if (!currentType.equals("Todos") && !item.type.equals(currentType)) continue;
            if (!currentGroup.equals("Todos") && !item.group.equals(currentGroup)) continue;
            if (!q.isEmpty()) {
                String hay = (item.name + " " + item.group + " " + item.type).toLowerCase(Locale.ROOT);
                if (!hay.contains(q)) continue;
            }
            filteredItems.add(item);
        }
        adapter.notifyDataSetChanged();
        String tipo = favoritesOnly ? "Favoritos" : currentType;
        updateStatus(filteredItems.size() + " exibidos / " + allItems.size() + " total • " + tipo + " • " + currentGroup);
    }

    private void rebuildCategories() {
        if (categoryBar == null) return;
        categoryBar.removeAllViews();
        addCategoryButton("Todos");
        LinkedHashSet<String> groups = new LinkedHashSet<>();
        for (IptvItem item : allItems) {
            if (favoritesOnly && !favoriteUrls.contains(item.url)) continue;
            if (!currentType.equals("Todos") && !item.type.equals(currentType)) continue;
            groups.add(item.group);
        }
        for (String g : groups) addCategoryButton(g);
    }

    private void addCategoryButton(final String name) {
        TextView b = smallButton(name.equals("Todos") ? "Todas categorias" : name, name.equals(currentGroup));
        b.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { currentGroup = name; rebuildCategories(); applyFilter(); } });
        categoryBar.addView(b);
    }

    private void showItemActions(final IptvItem item) {
        final boolean fav = favoriteUrls.contains(item.url);
        String[] actions = new String[] { "Assistir agora", fav ? "Remover dos favoritos" : "Adicionar aos favoritos", "Ver detalhes" };
        new AlertDialog.Builder(this)
                .setTitle(item.name)
                .setItems(actions, (dialog, which) -> {
                    if (which == 0) play(item);
                    if (which == 1) toggleFavorite(item);
                    if (which == 2) showDetails(item);
                })
                .show();
    }

    private void play(IptvItem item) {
        Intent i = new Intent(this, PlayerActivity.class);
        i.putExtra("name", item.name);
        i.putExtra("url", item.url);
        i.putExtra("group", item.group);
        i.putExtra("type", item.type);
        startActivity(i);
    }

    private void toggleFavorite(IptvItem item) {
        if (favoriteUrls.contains(item.url)) {
            favoriteUrls.remove(item.url);
            toast("Removido dos favoritos");
        } else {
            favoriteUrls.add(item.url);
            toast("Adicionado aos favoritos");
        }
        prefs.edit().putStringSet("favorites", favoriteUrls).apply();
        applyFilter();
    }

    private void showDetails(IptvItem item) {
        String msg = "Tipo: " + item.type + "\nCategoria: " + item.group + "\n\nLink:\n" + item.url + "\n\nDica TV: OK/Enter abre, segurar OK favorita, Direita/Esquerda no player avança/volta 10s.";
        new AlertDialog.Builder(this).setTitle(item.name).setMessage(msg).setPositiveButton("Assistir", (d, w) -> play(item)).setNegativeButton("Fechar", null).show();
    }

    private void clearList() {
        new AlertDialog.Builder(this)
                .setTitle("Limpar lista da tela?")
                .setMessage("Isso não apaga seus favoritos nem os dados salvos de login/lista.")
                .setPositiveButton("Limpar", (d, w) -> {
                    allItems.clear(); filteredItems.clear(); adapter.notifyDataSetChanged(); rebuildCategories(); updateStatus("Lista limpa");
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void showHelp() {
        String msg = "1. M3U URL: cole sua lista IPTV autorizada.\n" +
                "2. Xtream: digite servidor, usuário e senha do seu painel.\n" +
                "3. Arquivo: abra um .m3u salvo no celular/TV Box.\n" +
                "4. No controle remoto: use DPAD para navegar, OK para abrir, segure OK para favoritar.\n" +
                "5. No player: esquerda/direita volta ou avança 10 segundos; OK pausa/continua.";
        new AlertDialog.Builder(this).setTitle("Como usar").setMessage(msg).setPositiveButton("Entendi", null).show();
    }

    private void setLoading(boolean loading, String msg) {
        progress.setVisibility(loading ? View.VISIBLE : View.GONE);
        updateStatus(msg);
    }

    private void updateStatus(String text) {
        status.setText(text);
    }

    private void showError(String title, String message) {
        new AlertDialog.Builder(this).setTitle(title).setMessage(message == null ? "Erro desconhecido" : message).setPositiveButton("OK", null).show();
    }

    private void addTopButton(LinearLayout parent, String label, View.OnClickListener listener) {
        TextView b = bigButton(label);
        b.setOnClickListener(listener);
        parent.addView(b);
    }

    private TextView bigButton(String label) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextColor(white);
        b.setTextSize(isTv() ? 17 : 14);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setClickable(true);
        b.setSingleLine(true);
        b.setPadding(dp(14), dp(10), dp(14), dp(10));
        b.setBackground(selector());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, dp(8), dp(8), dp(8));
        b.setLayoutParams(lp);
        return b;
    }

    private TextView smallButton(String label, boolean selected) {
        TextView b = new TextView(this);
        b.setText(label);
        b.setTextColor(selected ? Color.BLACK : soft);
        b.setTextSize(isTv() ? 15 : 12);
        b.setTypeface(Typeface.DEFAULT_BOLD);
        b.setGravity(Gravity.CENTER);
        b.setFocusable(true);
        b.setClickable(true);
        b.setSingleLine(true);
        b.setEllipsize(TextUtils.TruncateAt.END);
        b.setMaxWidth(dp(isTv() ? 260 : 190));
        b.setPadding(dp(12), dp(7), dp(12), dp(7));
        b.setBackground(selected ? round(neon, dp(20), neon, dp(1)) : selectorSmall());
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.setMargins(0, dp(4), dp(8), dp(6));
        b.setLayoutParams(lp);
        return b;
    }

    private GradientDrawable round(int color, int radius, int stroke, int strokeWidth) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(radius);
        if (strokeWidth > 0) g.setStroke(strokeWidth, stroke);
        return g;
    }

    private StateListDrawable selector() {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, round(blue, dp(12), Color.WHITE, dp(2)));
        s.addState(new int[]{android.R.attr.state_focused}, round(neon, dp(12), Color.WHITE, dp(2)));
        s.addState(new int[]{android.R.attr.state_selected}, round(neon, dp(12), Color.WHITE, dp(2)));
        s.addState(new int[]{}, round(card2, dp(12), Color.rgb(47, 64, 82), dp(1)));
        return s;
    }

    private StateListDrawable selectorSmall() {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, round(neon, dp(20), Color.WHITE, dp(2)));
        s.addState(new int[]{}, round(card, dp(20), Color.rgb(44, 60, 76), dp(1)));
        return s;
    }

    private StateListDrawable selectorGrid() {
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_pressed}, round(Color.argb(150, 61, 183, 255), dp(16), Color.WHITE, dp(3)));
        s.addState(new int[]{android.R.attr.state_focused}, round(Color.argb(150, 0, 245, 138), dp(16), Color.WHITE, dp(3)));
        s.addState(new int[]{android.R.attr.state_selected}, round(Color.argb(150, 0, 245, 138), dp(16), Color.WHITE, dp(3)));
        s.addState(new int[]{}, round(Color.TRANSPARENT, dp(16), Color.TRANSPARENT, 0));
        return s;
    }

    private int dp(float v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private boolean isTv() {
        int ui = getResources().getConfiguration().uiMode & Configuration.UI_MODE_TYPE_MASK;
        return ui == Configuration.UI_MODE_TYPE_TELEVISION;
    }

    private void hideKeyboard(View v) {
        try { ((InputMethodManager) getSystemService(INPUT_METHOD_SERVICE)).hideSoftInputFromWindow(v.getWindowToken(), 0); } catch (Exception ignored) {}
    }

    private void toast(String m) { Toast.makeText(this, m, Toast.LENGTH_SHORT).show(); }

    private class CardAdapter extends BaseAdapter {
        public int getCount() { return filteredItems.size(); }
        public Object getItem(int position) { return filteredItems.get(position); }
        public long getItemId(int position) { return position; }

        public View getView(int position, View convertView, ViewGroup parent) {
            IptvItem item = filteredItems.get(position);
            LinearLayout box = new LinearLayout(MainActivity.this);
            box.setOrientation(LinearLayout.VERTICAL);
            box.setPadding(dp(10), dp(10), dp(10), dp(10));
            box.setMinimumHeight(dp(isTv() ? 124 : 108));
            box.setBackground(round(card, dp(14), Color.rgb(38, 55, 70), dp(1)));
            box.setFocusable(false);

            TextView tag = new TextView(MainActivity.this);
            String fav = favoriteUrls.contains(item.url) ? "★ " : "";
            tag.setText(fav + item.type.toUpperCase(Locale.ROOT));
            tag.setTextColor(item.type.equals("Canal") ? neon : blue);
            tag.setTextSize(isTv() ? 13 : 11);
            tag.setTypeface(Typeface.DEFAULT_BOLD);
            tag.setSingleLine(true);
            box.addView(tag, new LinearLayout.LayoutParams(-1, -2));

            TextView name = new TextView(MainActivity.this);
            name.setText(item.name);
            name.setTextColor(white);
            name.setTextSize(isTv() ? 17 : 14);
            name.setTypeface(Typeface.DEFAULT_BOLD);
            name.setMaxLines(2);
            name.setEllipsize(TextUtils.TruncateAt.END);
            LinearLayout.LayoutParams nlp = new LinearLayout.LayoutParams(-1, 0, 1);
            nlp.setMargins(0, dp(6), 0, dp(6));
            box.addView(name, nlp);

            TextView group = new TextView(MainActivity.this);
            group.setText(item.group);
            group.setTextColor(soft);
            group.setTextSize(isTv() ? 12 : 10);
            group.setSingleLine(true);
            group.setEllipsize(TextUtils.TruncateAt.END);
            box.addView(group, new LinearLayout.LayoutParams(-1, -2));
            return box;
        }
    }
}
