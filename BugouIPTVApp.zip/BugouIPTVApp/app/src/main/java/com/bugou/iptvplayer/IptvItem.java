package com.bugou.iptvplayer;

public class IptvItem {
    public final String name;
    public final String url;
    public final String logo;
    public final String group;
    public final String type;

    public IptvItem(String name, String url, String logo, String group, String type) {
        this.name = clean(name, "Sem nome");
        this.url = clean(url, "");
        this.logo = clean(logo, "");
        this.group = clean(group, "Sem categoria");
        this.type = clean(type, "Canal");
    }

    private static String clean(String value, String fallback) {
        if (value == null) return fallback;
        String v = value.trim();
        return v.isEmpty() ? fallback : v;
    }
}
