package com.bugou.iptvplayer;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.GZIPInputStream;

public final class IptvParser {
    private static final Pattern ATTR_PATTERN = Pattern.compile("([a-zA-Z0-9_-]+)\\s*=\\s*\"([^\"]*)\"");

    private IptvParser() {}

    public static ArrayList<IptvItem> loadFromUrl(String sourceUrl) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(sourceUrl).openConnection();
        conn.setConnectTimeout(20000);
        conn.setReadTimeout(30000);
        conn.setInstanceFollowRedirects(true);
        conn.setRequestProperty("User-Agent", "BugouIPTV/1.0 Android");
        conn.setRequestProperty("Accept", "application/x-mpegURL,application/vnd.apple.mpegurl,text/plain,*/*");
        conn.setRequestProperty("Accept-Encoding", "gzip");
        int code = conn.getResponseCode();
        if (code < 200 || code >= 400) throw new Exception("Servidor respondeu código " + code);
        InputStream in = conn.getInputStream();
        String enc = conn.getContentEncoding();
        if (enc != null && enc.toLowerCase().contains("gzip")) in = new GZIPInputStream(in);
        String text = readAll(in);
        conn.disconnect();
        return parse(text);
    }

    public static ArrayList<IptvItem> loadFromInputStream(InputStream in) throws Exception {
        return parse(readAll(in));
    }

    private static String readAll(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) out.write(buf, 0, n);
            String raw = out.toString(StandardCharsets.UTF_8.name());
            if (raw.indexOf('\uFFFD') >= 0) raw = out.toString("ISO-8859-1");
            return raw;
        } finally {
            in.close();
        }
    }

    public static ArrayList<IptvItem> parse(String text) throws Exception {
        ArrayList<IptvItem> items = new ArrayList<>();
        if (text == null || text.trim().isEmpty()) throw new Exception("Lista vazia");
        BufferedReader br = new BufferedReader(new InputStreamReader(new java.io.ByteArrayInputStream(text.getBytes(StandardCharsets.UTF_8)), StandardCharsets.UTF_8));
        String line;
        Pending pending = null;
        int unnamed = 1;
        while ((line = br.readLine()) != null) {
            line = line.trim();
            if (line.isEmpty()) continue;
            if (line.startsWith("#EXTINF")) {
                pending = parseInfo(line, unnamed++);
                continue;
            }
            if (line.startsWith("#")) continue;
            if (looksLikeStream(line)) {
                if (pending == null) pending = new Pending("Canal " + unnamed++, "", "");
                items.add(new IptvItem(pending.name, line, pending.logo, pending.group, classify(pending.name, pending.group, line)));
                pending = null;
            }
        }
        if (items.isEmpty()) throw new Exception("Nenhum link de vídeo foi encontrado na lista");
        return items;
    }

    private static Pending parseInfo(String line, int fallbackIndex) {
        Map<String, String> attrs = new LinkedHashMap<>();
        Matcher m = ATTR_PATTERN.matcher(line);
        while (m.find()) attrs.put(m.group(1).toLowerCase(), html(m.group(2)));
        String name = attrs.get("tvg-name");
        int comma = line.lastIndexOf(',');
        if ((name == null || name.trim().isEmpty()) && comma >= 0 && comma + 1 < line.length()) name = html(line.substring(comma + 1).trim());
        if (name == null || name.trim().isEmpty()) name = "Canal " + fallbackIndex;
        String logo = attrs.containsKey("tvg-logo") ? attrs.get("tvg-logo") : "";
        String group = attrs.containsKey("group-title") ? attrs.get("group-title") : "Sem categoria";
        return new Pending(name, logo, group);
    }

    private static boolean looksLikeStream(String line) {
        String l = line.toLowerCase();
        return l.startsWith("http://") || l.startsWith("https://") || l.startsWith("rtsp://") || l.startsWith("rtmp://");
    }

    private static String classify(String name, String group, String url) {
        String hay = ((name == null ? "" : name) + " " + (group == null ? "" : group) + " " + (url == null ? "" : url)).toLowerCase();
        if (hay.contains("filme") || hay.contains("movie") || hay.contains("movies") || hay.contains("vod") || hay.matches(".*\\.(mp4|mkv|avi|mov)(\\?.*)?$")) return "Filme";
        if (hay.contains("série") || hay.contains("serie") || hay.contains("series") || hay.contains("temporada") || hay.contains("season") || hay.contains("episode") || hay.contains("episódio") || hay.contains("episodio")) return "Série";
        return "Canal";
    }

    private static String html(String s) {
        if (s == null) return "";
        return s.replace("&amp;", "&").replace("&quot;", "\"").replace("&#039;", "'").replace("&apos;", "'").replace("&lt;", "<").replace("&gt;", ">").trim();
    }

    private static class Pending {
        final String name;
        final String logo;
        final String group;
        Pending(String name, String logo, String group) {
            this.name = name;
            this.logo = logo;
            this.group = group;
        }
    }
}
