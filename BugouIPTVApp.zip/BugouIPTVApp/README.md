# Bugou IPTV Android

Projeto Android nativo em Java para compilar APK pelo GitHub Actions.

## O que já vem pronto

- Tela inicial IPTV com visual escuro/profissional.
- Campo para adicionar lista M3U por URL.
- Login Xtream Codes: servidor, usuário e senha.
- Opção para abrir arquivo `.m3u` local.
- Categorias por `group-title` da lista.
- Filtros: Todos, Canais, Filmes, Séries e Favoritos.
- Pesquisa por nome, categoria e tipo.
- Player interno com AndroidX Media3/ExoPlayer.
- Suporte a HLS/M3U8, DASH, RTSP e links diretos compatíveis com ExoPlayer.
- Controle remoto: DPAD, OK/Enter, avançar/voltar 10 segundos.
- Continua de onde parou ou reinicia.
- Manifest compatível com celular, tablet, Android TV, TV Box e Fire TV.
- Cleartext habilitado para listas HTTP antigas.
- Workflow do GitHub para gerar APK automaticamente.

## Como compilar pelo GitHub

1. Crie um repositório no GitHub.
2. Extraia este ZIP e envie todos os arquivos para o repositório.
3. Vá em **Actions**.
4. Abra **Build APK**.
5. Clique em **Run workflow**.
6. Quando terminar, baixe o APK em **Artifacts** com o nome `Bugou-IPTV-debug-apk`.

## Como usar o app

- Abra o app.
- Clique em **M3U URL** e cole sua lista IPTV autorizada.
- Ou clique em **Xtream** e coloque servidor, usuário e senha.
- Ou clique em **Arquivo** e selecione um `.m3u` salvo.
- Clique em um item e escolha **Assistir agora**.
- Segure OK/toque longo para favoritar.

## Observação importante

Este projeto não inclui listas, canais, filmes ou séries. Use apenas conteúdo próprio, autorizado ou legal.
